package com.listenergao.lamemp3;

/**
 * create on 2018/10/14
 *
 * @author ListenerGao
 */
public class Mp3Encoder {

    public native void encode();
}
