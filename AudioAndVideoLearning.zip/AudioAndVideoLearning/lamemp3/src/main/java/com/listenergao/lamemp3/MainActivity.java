package com.listenergao.lamemp3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * create on 18/10/14
 *
 * @author listenergao
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
