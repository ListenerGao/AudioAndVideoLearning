package com.listenergao.audioandvideolearning.utils;

/**
 * @author listenergao
 */
public class CommonConfig {

    public final static String DRAW_PICTURE = "drawPicture";
    public final static String RECORD = "record";
}
