package com.listenergao.audioandvideolearning.mode;

public class CategoryBean {

    public String categoryName;
    public String tag;

    public CategoryBean(String categoryName, String tag) {
        this.categoryName = categoryName;
        this.tag = tag;
    }
}
